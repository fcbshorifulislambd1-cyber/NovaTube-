import './novatube.css';
import { createContext, type FormEvent, type ReactNode, useContext, useEffect, useMemo, useState } from 'react';
import { ClerkProvider, SignIn, SignUp, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import {
  ArrowDown, ArrowRight, ArrowUp, BadgeCheck, Check, Clapperboard, Compass, Film, Heart,
  Home, LogOut, Play, Plus, Search, Share2, Sparkles, ThumbsUp, Upload as UploadIcon,
  UserRound, Video, X, Zap,
} from 'lucide-react';
import { Link, Redirect, Route, Router as WouterRouter, Switch, useLocation, useParams } from 'wouter';

export type VideoItem = {
  id: string; title: string; creator: string; creatorId: string; avatar: string;
  thumbnail: string; videoUrl: string; description: string; category: string;
  views: number; createdAt: string; duration: string; isShort: boolean;
  local?: boolean; blobKey?: string;
};
type CommentItem = { id: string; videoId: string; userId: string; author: string; avatar: string; text: string; createdAt: string };
type Persisted = { videos: VideoItem[]; likes: string[]; subscriptions: string[]; comments: CommentItem[] };
type Store = Persisted & {
  ready: boolean;
  objectUrls: Record<string, string>;
  toggleLike: (id: string) => void;
  toggleSubscribe: (id: string) => void;
  addComment: (videoId: string, text: string, author: string, avatar: string, userId: string) => void;
  publishVideo: (video: VideoItem, blob: Blob) => Promise<void>;
  removeVideo: (id: string) => Promise<void>;
  toast: (message: string) => void;
};
const StoreContext = createContext<Store | null>(null);
const STORAGE_KEY = 'novatube-demo-v1';
const categories = ['For you', 'Music', 'Gaming', 'Lifestyle', 'Learning', 'Comedy', 'Shorts'];
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const seedVideos: VideoItem[] = [
  { id: 'night-shift', title: 'We turned the practice room into a tiny concert', creator: 'Mina Sol', creatorId: 'mina-sol', avatar: 'MS', thumbnail: `${basePath}/creator-rehearsal.jpg`, videoUrl: '', description: 'A little noise, a room full of friends, and the song we almost did not share. Shot after midnight in Brooklyn.', category: 'Music', views: 18420, createdAt: '2 days ago', duration: '08:42', isShort: false },
  { id: 'rooftop-lines', title: 'The last light on this roof is unreal', creator: 'Theo Park', creatorId: 'theo-park', avatar: 'TP', thumbnail: `${basePath}/rooftop-skate.jpg`, videoUrl: '', description: 'A few laps before the city wakes up. No plan, just a board and a little borrowed sunset.', category: 'Lifestyle', views: 9341, createdAt: '5 hours ago', duration: '04:18', isShort: false },
  { id: 'pasta-after-hours', title: 'Pasta from scratch, no recipe and no rush', creator: 'Nico Alvarez', creatorId: 'nico-alvarez', avatar: 'NA', thumbnail: `${basePath}/kitchen-video.jpg`, videoUrl: '', description: 'A quiet kitchen, a red sauce, and the kind of dinner that turns into the whole evening.', category: 'Lifestyle', views: 52708, createdAt: '1 week ago', duration: '12:06', isShort: false },
  { id: 'tiny-desk-loop', title: 'One loop, one lamp, one very late night', creator: 'Mina Sol', creatorId: 'mina-sol', avatar: 'MS', thumbnail: `${basePath}/creator-rehearsal.jpg`, videoUrl: '', description: 'A loop I made while the rain kept tapping on the window. Headphones recommended.', category: 'Music', views: 7620, createdAt: '3 days ago', duration: '00:38', isShort: true },
  { id: 'skate-quick-cut', title: 'Three tries. The last one counted.', creator: 'Theo Park', creatorId: 'theo-park', avatar: 'TP', thumbnail: `${basePath}/rooftop-skate.jpg`, videoUrl: '', description: 'A tiny edit from a good session. Keep showing up.', category: 'Shorts', views: 128300, createdAt: 'Yesterday', duration: '00:24', isShort: true },
  { id: 'supper-short', title: 'Crispy edges are the whole point', creator: 'Nico Alvarez', creatorId: 'nico-alvarez', avatar: 'NA', thumbnail: `${basePath}/kitchen-video.jpg`, videoUrl: '', description: 'The quick version of tonight’s kitchen experiment.', category: 'Shorts', views: 31900, createdAt: '4 days ago', duration: '00:31', isShort: true },
  { id: 'desk-set', title: 'My tiny desk setup, every cable has a story', creator: 'Jules Kim', creatorId: 'jules-kim', avatar: 'JK', thumbnail: `${basePath}/creator-rehearsal.jpg`, videoUrl: '', description: 'Building a creative corner in the space between the bed and the window.', category: 'Learning', views: 14900, createdAt: '6 days ago', duration: '06:54', isShort: false },
  { id: 'night-ride', title: 'A city ride with no destination', creator: 'Amari Lewis', creatorId: 'amari-lewis', avatar: 'AL', thumbnail: `${basePath}/rooftop-skate.jpg`, videoUrl: '', description: 'A small reminder to take the long way home sometimes.', category: 'Lifestyle', views: 26300, createdAt: '2 weeks ago', duration: '09:12', isShort: false },
].map(video => ({ ...video, videoUrl: `${basePath}/demo-flowers-cc0.mp4` }));
const defaultPersisted: Persisted = { videos: [], likes: [], subscriptions: [], comments: [] };

function getDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('novatube-local-media', 1);
    request.onupgradeneeded = () => request.result.createObjectStore('uploads');
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
async function saveBlob(key: string, blob: Blob) {
  const db = await getDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction('uploads', 'readwrite'); tx.objectStore('uploads').put(blob, key);
    tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error);
  });
  db.close();
}
async function deleteBlob(key: string) {
  const db = await getDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction('uploads', 'readwrite'); tx.objectStore('uploads').delete(key);
    tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error);
  });
  db.close();
}
async function loadBlob(key: string): Promise<Blob | undefined> {
  const db = await getDb();
  const value = await new Promise<Blob | undefined>((resolve, reject) => {
    const request = db.transaction('uploads', 'readonly').objectStore('uploads').get(key);
    request.onsuccess = () => resolve(request.result as Blob | undefined); request.onerror = () => reject(request.error);
  });
  db.close(); return value;
}
function useStore() {
  const value = useContext(StoreContext);
  if (!value) throw new Error('NovaTube store is unavailable');
  return value;
}
function formatViews(views: number) {
  if (views >= 1_000_000) return `${(views / 1_000_000).toFixed(1)}M views`;
  if (views >= 1_000) return `${(views / 1_000).toFixed(1)}K views`;
  return `${views} views`;
}
function getInitial(): Persisted {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') as Partial<Persisted>;
    return { ...defaultPersisted, ...parsed, videos: parsed.videos || [] };
  } catch { return defaultPersisted; }
}
function Avatar({ initials, testId }: { initials: string; testId?: string }) {
  return <div className="avatar" data-testid={testId || `img-avatar-${initials.toLowerCase()}`}>{initials || 'N'}</div>;
}
function Brand() {
  return <Link href="/" className="brand" data-testid="link-brand"><span className="brand-mark"><Play /></span><span>nova<em>tube</em></span></Link>;
}

function AppState({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Persisted>(getInitial);
  const [ready, setReady] = useState(false);
  const [notice, setNotice] = useState('');
  const [objectUrls, setObjectUrls] = useState<Record<string, string>>({});
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);
  useEffect(() => {
    let mounted = true;
    const restore = async () => {
      try {
        const pairs = await Promise.all(state.videos.filter(v => v.local && v.blobKey).map(async v => [v.id, await loadBlob(v.blobKey!)] as const));
        if (!mounted) return;
        const next: Record<string, string> = {};
        pairs.forEach(([id, blob]) => {
          if (!blob) return;
          const url = URL.createObjectURL(blob);
          next[id] = url;
          setState(current => ({ ...current, videos: current.videos.map(video => video.id === id ? { ...video, videoUrl: url } : video) }));
        });
        setObjectUrls(next);
      } catch { /* Local uploads remain listed if browser storage is unavailable. */ }
      setReady(true);
    };
    void restore();
    return () => { mounted = false; };
  // Restore only once, from the initial persisted record set.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => () => Object.values(objectUrls).forEach(URL.revokeObjectURL), []);
  const toast = (message: string) => { setNotice(message); window.setTimeout(() => setNotice(''), 2800); };
  const value = useMemo<Store>(() => ({
    ...state, ready, objectUrls, toast,
    toggleLike: id => setState(current => ({ ...current, likes: current.likes.includes(id) ? current.likes.filter(x => x !== id) : [...current.likes, id] })),
    toggleSubscribe: id => setState(current => ({ ...current, subscriptions: current.subscriptions.includes(id) ? current.subscriptions.filter(x => x !== id) : [...current.subscriptions, id] })),
    addComment: (videoId, text, author, avatar, userId) => setState(current => ({ ...current, comments: [{ id: crypto.randomUUID(), videoId, userId, author, avatar, text, createdAt: 'just now' }, ...current.comments] })),
    publishVideo: async (video, blob) => {
      await saveBlob(video.blobKey!, blob);
      const url = URL.createObjectURL(blob);
      const thumbUrl = URL.createObjectURL(blob);
      setObjectUrls(current => ({ ...current, [video.id]: url }));
      setState(current => ({ ...current, videos: [{ ...video, thumbnail: thumbUrl, videoUrl: url }, ...current.videos] }));
    },
    removeVideo: async id => {
      const item = state.videos.find(v => v.id === id);
      if (item?.blobKey) await deleteBlob(item.blobKey);
      setObjectUrls(current => { if (current[id]) URL.revokeObjectURL(current[id]); const copy = { ...current }; delete copy[id]; return copy; });
      setState(current => ({ ...current, videos: current.videos.filter(v => v.id !== id) }));
    },
  }), [state, ready, objectUrls]);
  return <StoreContext.Provider value={value}>{children}{notice && <div className="toast" role="status" data-testid="status-toast">{notice}</div>}</StoreContext.Provider>;
}

function AppShell({ children }: { children: ReactNode }) {
  const { user } = useUser();
  const { signOut } = useClerk();
  const [location, setLocation] = useLocation();
  const [query, setQuery] = useState('');
  const profileHref = '/profile';
  const nav = [
    { label: 'Home', href: '/user-portal', icon: Home },
    { label: 'Shorts', href: '/shorts', icon: Clapperboard },
    { label: 'Upload', href: '/upload', icon: Plus },
    { label: 'Profile', href: profileHref, icon: UserRound },
  ];
  const submitSearch = (event: FormEvent) => {
    event.preventDefault();
    if (query.trim()) setLocation(`/search?q=${encodeURIComponent(query.trim())}`);
  };
  const active = (href: string) => href === '/user-portal' ? location === '/' || location === '/user-portal' : location.startsWith(href);
  const displayName = user?.fullName || user?.username || user?.primaryEmailAddress?.emailAddress?.split('@')[0] || 'Your space';
  const initials = user?.firstName?.slice(0, 1) && user?.lastName?.slice(0, 1) ? `${user.firstName[0]}${user.lastName[0]}` : displayName.slice(0, 2);
  return <div className="nt-app">
    <header className="topbar">
      <Brand />
      <form className="searchbar" role="search" onSubmit={submitSearch} data-testid="form-search">
        <input aria-label="Search videos" placeholder="Search videos, creators..." value={query} onChange={event => setQuery(event.target.value)} data-testid="input-search" />
        {query && <button type="button" aria-label="Clear search" onClick={() => setQuery('')} data-testid="button-clear-search"><X size={16} /></button>}
        <button type="submit" aria-label="Search" data-testid="button-search"><Search size={18} /></button>
      </form>
      <form className="searchbar mobile-search" role="search" onSubmit={submitSearch}>
        <input aria-label="Search videos" placeholder="Search NovaTube" value={query} onChange={event => setQuery(event.target.value)} data-testid="input-search-mobile" />
        <button type="submit" aria-label="Search" data-testid="button-search-mobile"><Search size={18} /></button>
      </form>
      <div className="top-actions">
        {!user && <Link className="top-button" href="/sign-in" data-testid="link-sign-in">Sign in</Link>}
        {user && <div className="user-chip"><Avatar initials={initials} /><span>{displayName}</span><button className="icon-button" aria-label="Sign out" title="Sign out" onClick={() => void signOut({ redirectUrl: `${basePath || ''}/` })} data-testid="button-sign-out"><LogOut size={17} /></button></div>}
      </div>
    </header>
    <div className="layout">
      <aside className="sidebar">
        <p className="side-label">Explore</p>
        <nav className="nav-list" aria-label="Main navigation">
          {nav.slice(0, 2).map(({ label, href, icon: Icon }) => <Link key={href} href={href} className={`nav-link ${active(href) ? 'active' : ''}`} data-testid={`link-nav-${label.toLowerCase()}`}><Icon size={19} /><span>{label}</span></Link>)}
          <button className="nav-link" onClick={() => setLocation('/search?q=')} data-testid="button-explore"><Compass size={19} /><span>Explore</span></button>
        </nav>
        <div className="sidebar-rule" />
        <p className="side-label">Your corner</p>
        <nav className="nav-list">
          {nav.slice(2).map(({ label, href, icon: Icon }) => <Link key={href} href={href} className={`nav-link ${active(href) ? 'active' : ''}`} data-testid={`link-nav-${label.toLowerCase()}`}><Icon size={19} /><span>{label}</span></Link>)}
        </nav>
        <div className="sidebar-note"><strong>Make something yours.</strong><p>Share a moment, a process, or a half-formed idea.</p><Link href="/upload" data-testid="link-sidebar-upload">Start creating <ArrowRight size={14} /></Link></div>
      </aside>
      <main className="main-content">{children}</main>
    </div>
    <nav className="mobile-nav" aria-label="Bottom navigation">
      {nav.map(({ label, href, icon: Icon }) => <Link key={href} href={href} className={active(href) ? 'active' : ''} data-testid={`mobile-nav-${label.toLowerCase()}`}><Icon /><span>{label}</span></Link>)}
    </nav>
  </div>;
}

function VideoCard({ video }: { video: VideoItem }) {
  const { toast, toggleLike, likes } = useStore();
  const liked = likes.includes(video.id);
  return <article className="video-card" data-testid={`card-video-${video.id}`}>
    <Link href={`/watch/${video.id}`} className="thumb-link" data-testid={`link-watch-${video.id}`}>
      <img src={video.thumbnail} alt={`${video.title} thumbnail`} data-testid={`img-thumbnail-${video.id}`} />
      <div className="thumb-overlay"><span className="play-disc"><Play size={20} fill="currentColor" /></span></div>
      {video.local && <span className="local-badge"><Video size={11} /> Local demo</span>}
      <span className="duration">{video.duration}</span>
    </Link>
    <div className="video-meta">
      <Avatar initials={video.avatar} />
      <div className="video-copy">
        <Link className="video-title" href={`/watch/${video.id}`} data-testid={`text-title-${video.id}`}>{video.title}</Link>
        <div className="video-byline">{video.creator}</div>
        <div className="video-stats">{formatViews(video.views)} · {video.createdAt}</div>
      </div>
      <button className="video-more" title={liked ? 'Unlike video' : 'Like video'} aria-label={liked ? 'Unlike video' : 'Like video'} onClick={() => { toggleLike(video.id); toast(liked ? 'Removed from your liked videos' : 'Added to your liked videos'); }} data-testid={`button-like-${video.id}`}><Heart size={17} fill={liked ? 'currentColor' : 'none'} /></button>
    </div>
  </article>;
}

function Feed({ search = false }: { search?: boolean }) {
  const { videos, ready } = useStore();
  const params = new URLSearchParams(window.location.search);
  const query = params.get('q')?.trim() || '';
  const [category, setCategory] = useState('For you');
  const allVideos = [...videos, ...seedVideos];
  const filtered = allVideos.filter(video => {
    const categoryOk = category === 'For you' || (category === 'Shorts' ? video.isShort : video.category === category);
    const queryOk = !search || !query || `${video.title} ${video.creator} ${video.description} ${video.category}`.toLowerCase().includes(query.toLowerCase());
    return categoryOk && queryOk;
  });
  if (!ready) return <><div className="page-head"><div><div className="eyebrow">Your next favorite</div><h1>Find your frequency.</h1></div></div><div className="video-grid">{[1,2,3].map(i => <div key={i} className="video-card"><div className="thumb-link" style={{ background: '#23242a' }} /><div className="video-meta"><div className="avatar" /><div className="video-copy"><div style={{ height: 17, width: '88%', borderRadius: 5, background: '#26272d' }} /><div style={{ height: 12, width: '50%', marginTop: 9, borderRadius: 5, background: '#202127' }} /></div></div></div>)}</div></>;
  return <>
    <div className="page-head">
      <div><p className="eyebrow">{search ? 'Your search, your scene' : 'The good stuff, right now'}</p><h1 data-testid="text-feed-heading">{search ? (query ? `Results for “${query}”` : 'Search videos') : 'Find your frequency.'}</h1><p>{search ? `${filtered.length} ${filtered.length === 1 ? 'video' : 'videos'} worth a look.` : 'Fresh voices. Small moments. Big energy.'}</p></div>
      {search && <span className="pill"><Search size={12} /> Search</span>}
    </div>
    {!search && <section className="feature-banner" data-testid="banner-create"><div><p className="eyebrow">The floor is yours</p><h2>Your point of view belongs here.</h2><p>Make a little noise. Let people find you.</p><Link className="primary-button" href="/upload" data-testid="link-start-upload"><UploadIcon size={16} /> Upload a video</Link></div><span className="pill"><Sparkles size={13} /> Creator first</span></section>}
    <div className="category-row" aria-label="Video categories">
      {categories.map(item => <button key={item} className={`category-chip ${category === item ? 'selected' : ''}`} onClick={() => setCategory(item)} data-testid={`filter-${item.toLowerCase().replaceAll(' ', '-')}`}>{item}</button>)}
    </div>
    {filtered.length ? <div className="video-grid">{filtered.map((video, index) => <div key={video.id} style={{ animationDelay: `${Math.min(index, 8) * 45}ms` }}><VideoCard video={video} /></div>)}</div> :
      <div className="empty-state" data-testid="empty-search"><span className="empty-icon"><Search /></span><h2>No clips in this orbit yet.</h2><p>Try a different phrase or clear the category filter to see what creators are sharing.</p><button className="secondary-button" onClick={() => { setCategory('For you'); if (search) window.history.replaceState(null, '', `${basePath}/search`); }} data-testid="button-reset-search">Reset filters</button></div>}
  </>;
}

function HomeRedirect() {
  const { isLoaded, isSignedIn } = useUser();
  if (!isLoaded) return <div className="auth-shell"><div className="page-head"><h1>Loading your corner…</h1></div></div>;
  if (isSignedIn) return <Redirect to="/user-portal" />;
  return <AppShell><Feed /></AppShell>;
}
function PortalRedirect() {
  const { isLoaded, isSignedIn } = useUser();
  if (!isLoaded) return <div className="auth-shell"><div className="page-head"><h1>Loading your corner…</h1></div></div>;
  if (!isSignedIn) return <Redirect to="/" />;
  return <AppShell><Feed /></AppShell>;
}
function SearchPage() { return <AppShell><Feed search /></AppShell>; }

function WatchPage() {
  const { videoId } = useParams<{ videoId: string }>();
  const { videos, likes, comments, subscriptions, toggleLike, toggleSubscribe, addComment, toast, ready, objectUrls } = useStore();
  const { user } = useUser();
  const allVideos = [...videos, ...seedVideos];
  const video = allVideos.find(item => item.id === videoId);
  const [comment, setComment] = useState('');
  const playerUrl = video?.local ? objectUrls[video.id] || video.videoUrl : video?.videoUrl || '';
  const commentsForVideo = comments.filter(item => item.videoId === videoId);
  const creatorSubscribed = video ? subscriptions.includes(video.creatorId) : false;
  const sendComment = (event: FormEvent) => {
    event.preventDefault();
    if (!video || !comment.trim()) return;
    addComment(video.id, comment.trim(), user?.fullName || user?.username || 'Guest creator', user?.firstName?.slice(0,1) || 'G', user?.id || 'local-visitor');
    setComment(''); toast('Your comment is up');
  };
  const share = async () => {
    const url = window.location.href;
    try { await navigator.clipboard.writeText(url); toast('Link copied to clipboard'); }
    catch { window.prompt('Copy this video link', url); }
  };
  if (!ready) return <AppShell><div className="page-head"><h1>Loading video…</h1></div></AppShell>;
  if (!video) return <AppShell><div className="empty-state"><span className="empty-icon"><Film /></span><h2>That video has drifted off.</h2><p>It may have been removed from this device.</p><Link className="primary-button" href="/user-portal">Back to videos</Link></div></AppShell>;
  const nextVideos = allVideos.filter(v => v.id !== video.id).slice(0, 5);
  return <AppShell><div className="watch-layout">
    <div>
      <div className="player-frame">
        {playerUrl ? <video src={playerUrl} controls playsInline preload="metadata" poster={video.thumbnail} data-testid="video-player" /> :
          <div className="player-placeholder" data-testid="video-demo-player"><img src={video.thumbnail} alt="" /><div className="play-disc"><Play size={27} fill="currentColor" /></div>{video.local && <span className="local-badge">Local demo video</span>}</div>}
      </div>
      <h1 className="watch-title" data-testid="text-watch-title">{video.title}</h1>
      <div className="creator-strip">
        <Avatar initials={video.avatar} />
        <div><div className="creator-name">{video.creator} <BadgeCheck size={14} style={{ verticalAlign: 'middle', color: '#f36a61' }} /></div><div className="creator-sub">{formatViews(video.views)} · {video.createdAt}{video.local ? ' · Local demo' : ''}</div></div>
        {user?.id !== video.creatorId && <button className={`primary-button ${creatorSubscribed ? 'secondary-button' : ''}`} style={{ marginLeft: 'auto' }} onClick={() => { toggleSubscribe(video.creatorId); toast(creatorSubscribed ? 'Subscription removed' : `Subscribed to ${video.creator}`); }} data-testid="button-subscribe">{creatorSubscribed ? <><Check size={15} /> Subscribed</> : 'Subscribe'}</button>}
      </div>
      <div className="watch-actions">
        <button className={`icon-action ${likes.includes(video.id) ? 'liked' : ''}`} onClick={() => toggleLike(video.id)} data-testid="button-watch-like"><ThumbsUp size={16} /> {likes.includes(video.id) ? 'Liked' : 'Like'} <span>{likes.includes(video.id) ? '· 1' : ''}</span></button>
        <button className="icon-action" onClick={share} data-testid="button-share"><Share2 size={16} /> Share</button>
        <Link className="icon-action" href="/shorts" data-testid="link-watch-shorts"><Clapperboard size={16} /> Watch shorts</Link>
      </div>
      <div className="watch-description" data-testid="text-video-description"><strong>{formatViews(video.views)} · {video.createdAt}</strong><br />{video.description || 'A local creator video shared on NovaTube.'}{video.local && <div style={{ marginTop: 9 }}><span className="pill">Local demo upload</span></div>}</div>
      <section className="comment-panel">
        <h2 data-testid="text-comment-count">{commentsForVideo.length} {commentsForVideo.length === 1 ? 'comment' : 'comments'}</h2>
        <form className="comment-form" onSubmit={sendComment} data-testid="form-comment">
          <Avatar initials={user?.firstName?.slice(0,1) || 'G'} />
          <textarea aria-label="Add a comment" placeholder="Add a thought to the conversation…" value={comment} onChange={event => setComment(event.target.value)} data-testid="input-comment" />
          <button className="primary-button" type="submit" disabled={!comment.trim()} data-testid="button-post-comment">Post</button>
        </form>
        {commentsForVideo.length ? commentsForVideo.map(item => <div className="comment" key={item.id} data-testid={`comment-${item.id}`}><Avatar initials={item.avatar} /><div><span className="comment-author">{item.author}</span><span className="comment-date">{item.createdAt}</span><p className="comment-text">{item.text}</p></div></div>) : <p style={{ color: '#969398', fontSize: 13 }}>Be the first to say something real.</p>}
      </section>
    </div>
    <aside className="watch-aside"><div className="up-next"><h3>Keep the good stuff going</h3>{nextVideos.map(item => <Link href={`/watch/${item.id}`} className="next-card" key={item.id} data-testid={`link-next-${item.id}`}><img src={item.thumbnail} alt="" /><div><strong>{item.title}</strong><span>{item.creator} · {formatViews(item.views)}</span></div></Link>)}</div></aside>
  </div></AppShell>;
}

function ShortsPage() {
  const { videos, likes, toggleLike, toast, objectUrls } = useStore();
  const items = [...videos, ...seedVideos].filter(item => item.isShort);
  const [index, setIndex] = useState(0);
  const current = items[index];
  const move = (delta: number) => setIndex(old => (old + delta + items.length) % items.length);
  const share = async () => { if (!current) return; try { await navigator.clipboard.writeText(`${window.location.origin}${basePath}/watch/${current.id}`); toast('Short link copied'); } catch { toast('Share link ready to copy'); } };
  if (!current) return <AppShell><div className="empty-state"><span className="empty-icon"><Clapperboard /></span><h2>No shorts yet.</h2><p>Creators’ quick takes will show up here.</p><Link className="primary-button" href="/upload">Upload a video</Link></div></AppShell>;
  const shortUrl = current.local ? objectUrls[current.id] || current.videoUrl : current.videoUrl;
  return <AppShell><div className="shorts-page">
    <div className="shorts-heading"><div><p className="eyebrow">Fast takes. Full feelings.</p><h1 style={{ margin: 0, font: "700 29px 'Space Grotesk',sans-serif" }}>Shorts</h1></div><span className="pill"><Zap size={12} /> {index + 1} / {items.length}</span></div>
    <div className="shorts-stage">
      <div className="short-player" data-testid="short-player">{shortUrl ? <video src={shortUrl} poster={current.thumbnail} controls playsInline preload="metadata" data-testid="video-short-player" /> : <img src={current.thumbnail} alt={current.title} />}<div className="short-gradient" /><div className="short-info"><span className="local-badge">{current.local ? 'Local demo' : current.category}</span><h2>{current.title}</h2><p>{current.creator} · {formatViews(current.views)}</p></div></div>
      <div className="short-controls">
        <div><button className={`round-action ${likes.includes(current.id) ? 'liked' : ''}`} aria-label="Like short" onClick={() => { toggleLike(current.id); toast(likes.includes(current.id) ? 'Like removed' : 'Liked'); }} data-testid="button-short-like"><Heart fill={likes.includes(current.id) ? 'currentColor' : 'none'} /></button><div className="short-action-label">Like</div></div>
        <div><Link className="round-action" href={`/watch/${current.id}`} aria-label="Open full video" data-testid="link-short-watch"><Play size={19} /></Link><div className="short-action-label">Watch</div></div>
        <div><button className="round-action" aria-label="Share short" onClick={() => void share()} data-testid="button-short-share"><Share2 size={19} /></button><div className="short-action-label">Share</div></div>
        <div><button className="round-action" aria-label="Next short" onClick={() => move(1)} data-testid="button-next-short"><ArrowDown size={19} /></button><div className="short-action-label">Next</div></div>
        <div><button className="round-action" aria-label="Previous short" onClick={() => move(-1)} data-testid="button-previous-short"><ArrowUp size={19} /></button><div className="short-action-label">Back</div></div>
      </div>
    </div>
  </div></AppShell>;
}

function UploadPage() {
  const { publishVideo, toast } = useStore();
  const { user } = useUser();
  const [, setLocation] = useLocation();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Lifestyle');
  const [isShort, setIsShort] = useState(false);
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const chooseFile = (picked?: File) => {
    if (!picked) return;
    if (!picked.type.startsWith('video/')) { toast('Choose a video file to continue'); return; }
    if (picked.size > 500 * 1024 * 1024) { toast('This demo supports videos up to 500 MB'); return; }
    setFile(picked); setPreview(URL.createObjectURL(picked)); if (!title) setTitle(picked.name.replace(/\.[^.]+$/, '').replace(/[-_]/g, ' '));
  };
  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!file || !title.trim()) return;
    setBusy(true);
    const id = crypto.randomUUID();
    try {
      await publishVideo({
        id, title: title.trim(), creator: user?.fullName || user?.username || 'Local creator',
        creatorId: user?.id || 'local-visitor', avatar: user?.firstName?.slice(0,1) || 'LC',
        thumbnail: category === 'Music' ? `${basePath}/creator-rehearsal.jpg` : category === 'Lifestyle' ? `${basePath}/kitchen-video.jpg` : `${basePath}/rooftop-skate.jpg`, videoUrl: '', description: description.trim(), category,
        views: 0, createdAt: 'just now', duration: isShort ? '00:30' : 'Local video',
        isShort, local: true, blobKey: id,
      }, file);
      toast('Published on this device'); setFile(null); setPreview(''); setTitle(''); setDescription('');
      setLocation('/profile');
    } catch { toast('Upload could not be saved. Check browser storage and try again.'); }
    finally { setBusy(false); }
  };
  return <><div className="page-head"><div><p className="eyebrow">Made by you, saved here</p><h1>Put your video out there.</h1><p>Uploads are stored on this device for this NovaTube demo. Nothing is sent to a server.</p></div><span className="pill"><Video size={13} /> Local demo</span></div>
    <div className="upload-layout">
      <form className="upload-box" onSubmit={submit} data-testid="form-upload">
        {preview ? <div style={{ position: 'relative' }}><video className="upload-preview" src={preview} controls playsInline data-testid="video-upload-preview" /><button className="icon-button" type="button" aria-label="Remove selected video" onClick={() => { setFile(null); setPreview(''); }} style={{ position: 'absolute', top: 8, right: 8, background: '#17181dcc' }} data-testid="button-remove-upload"><X /></button></div> :
          <label className={`dropzone ${dragging ? 'dragging' : ''}`} onDragOver={event => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={event => { event.preventDefault(); setDragging(false); chooseFile(event.dataTransfer.files[0]); }} data-testid="dropzone-upload">
            <span className="dropzone-icon"><UploadIcon /></span><strong>Drop a video here, or browse</strong><span>MP4, MOV, WebM · up to 500 MB · stays on this device</span>
            <input type="file" accept="video/*" onChange={event => chooseFile(event.target.files?.[0])} aria-label="Choose video file" style={{ position: 'absolute', width: 1, height: 1, opacity: 0 }} data-testid="input-video-file" />
          </label>}
        <div className="field"><label htmlFor="video-title">Title</label><input id="video-title" value={title} onChange={event => setTitle(event.target.value)} maxLength={100} placeholder="Give this moment a name" data-testid="input-upload-title" /></div>
        <div className="field"><label htmlFor="video-description">Description</label><textarea id="video-description" value={description} onChange={event => setDescription(event.target.value)} maxLength={1000} placeholder="A little context goes a long way." data-testid="input-upload-description" /></div>
        <div className="field"><label htmlFor="video-category">Category</label><select id="video-category" value={category} onChange={event => setCategory(event.target.value)} data-testid="select-upload-category">{categories.filter(item => item !== 'For you').map(item => <option key={item} value={item}>{item}</option>)}</select></div>
        <label style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '17px 0', color: '#c9c5c4', fontSize: 13 }}><input type="checkbox" checked={isShort} onChange={event => setIsShort(event.target.checked)} data-testid="checkbox-upload-short" /> Mark as a short-form video</label>
        <button className="primary-button" type="submit" disabled={!file || !title.trim() || busy} style={{ width: '100%' }} data-testid="button-publish-upload">{busy ? 'Saving locally…' : <><UploadIcon size={16} /> Publish locally</>}</button>
      </form>
      <aside className="upload-info"><span className="empty-icon"><Film /></span><h2>Your video stays yours.</h2><p>This is a browser-local demo. Your uploaded video file and its details are saved only in this browser on this device.</p><ul><li>Video blobs persist in IndexedDB.</li><li>Title, category, and description live in local storage.</li><li>Local/demo videos are clearly labeled in your feed.</li></ul><p>For a real audience, publishing would need a video hosting service. This demo does not send uploads anywhere.</p></aside>
    </div>
  </>;
}

function ProfilePage() {
  const { videos, likes, removeVideo, toast } = useStore();
  const { user, isLoaded } = useUser();
  const { signOut } = useClerk();
  const currentId = user?.id || 'local-visitor';
  const name = user?.fullName || user?.username || 'Local creator';
  const initials = user?.firstName?.slice(0,1) || 'LC';
  const owned = videos.filter(video => video.creatorId === currentId);
  const liked = [...videos, ...seedVideos].filter(video => likes.includes(video.id));
  if (!isLoaded) return <div className="page-head"><h1>Loading your profile…</h1></div>;
  const confirmRemove = async (video: VideoItem) => {
    if (window.confirm(`Remove “${video.title}” from this device?`)) { await removeVideo(video.id); toast('Local video removed'); }
  };
  return <>
    <div className="page-head"><div><p className="eyebrow">Your corner of NovaTube</p><h1>Profile</h1></div>{user ? <button className="secondary-button" onClick={() => void signOut({ redirectUrl: `${basePath || ''}/` })} data-testid="button-profile-sign-out"><LogOut size={15} /> Sign out</button> : <Link className="secondary-button" href="/sign-in" data-testid="link-profile-sign-in">Sign in</Link>}</div>
    <section className="profile-hero" data-testid="section-profile">
      <Avatar initials={user?.firstName?.slice(0,1) || initials} />
      <div><h2 data-testid="text-profile-name">{name}</h2><p>{user?.primaryEmailAddress?.emailAddress || 'Local demo profile · uploads stay on this device'}</p>
        <div className="profile-stats"><div><strong>{owned.length}</strong><span>Videos</span></div><div><strong>{likes.length}</strong><span>Likes</span></div><div><strong>Local</strong><span>Storage</span></div></div>
      </div>
    </section>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}><h2 className="section-title">Your videos</h2><Link className="secondary-button" href="/upload" data-testid="link-profile-upload"><Plus size={15} /> Create</Link></div>
    {owned.length ? <div className="video-grid">{owned.map(video => <article key={video.id} className="video-card"><Link className="thumb-link" href={`/watch/${video.id}`}><img src={video.thumbnail} alt={video.title} /><span className="local-badge">Local demo</span><span className="duration">{video.duration}</span></Link><div className="video-meta"><Avatar initials={video.avatar} /><div className="video-copy"><Link className="video-title" href={`/watch/${video.id}`}>{video.title}</Link><div className="video-stats">Saved on this device · {video.category}</div></div><button className="video-more" aria-label={`Remove ${video.title}`} title="Remove local video" onClick={() => void confirmRemove(video)} data-testid={`button-delete-video-${video.id}`}><X size={17} /></button></div></article>)}</div> :
      <div className="empty-state"><span className="empty-icon"><Video /></span><h2>Your first video starts here.</h2><p>Share something you made or noticed. It will be saved locally and ready to replay on this device.</p><Link className="primary-button" href="/upload" data-testid="link-empty-upload"><UploadIcon size={16} /> Upload a video</Link></div>}
    <h2 className="section-title">Videos you liked</h2>
    {liked.length ? <div className="video-grid">{liked.map(video => <VideoCard video={video} key={`liked-${video.id}`} />)}</div> : <p style={{ color: '#989498', fontSize: 13 }}>Tap the heart on a video to keep it close.</p>}
  </>;
}

function AuthPage({ mode }: { mode: 'sign-in' | 'sign-up' }) {
  return <div className="auth-shell"><div className="auth-top"><Brand /></div><div><p className="auth-kicker">{mode === 'sign-in' ? 'Welcome back to the videos, voices, and small moments you came for.' : 'Join a place where creators get to sound like themselves.'}</p>{mode === 'sign-in' ? <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /> : <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />}</div></div>;
}
const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: { logoPlacement: 'inside' as const, logoLinkUrl: basePath || '/', logoImageUrl: `${window.location.origin}${basePath}/logo.svg` },
  variables: { colorPrimary: '#ed5149', colorForeground: '#f4f1ee', colorMutedForeground: '#aaa6a5', colorDanger: '#ff6c62', colorBackground: '#1a1b20', colorInput: '#141519', colorInputForeground: '#f4f1ee', colorNeutral: '#48434a', fontFamily: 'DM Sans, sans-serif', borderRadius: '14px' },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#1a1b20] rounded-2xl w-[440px] max-w-full overflow-hidden',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#f4f1ee] font-semibold',
    headerSubtitle: 'text-[#aaa6a5]',
    socialButtonsBlockButtonText: 'text-[#f4f1ee]',
    formFieldLabel: 'text-[#e7e2df]',
    footerActionLink: 'text-[#ff776e]',
    footerActionText: 'text-[#aaa6a5]',
    dividerText: 'text-[#aaa6a5]',
    identityPreviewEditButton: 'text-[#ff776e]',
    formFieldSuccessText: 'text-[#b7d9ca]',
    alertText: 'text-[#f4f1ee]',
    logoBox: 'rounded-xl',
    logoImage: 'rounded-xl',
    socialButtonsBlockButton: 'border-[#3c3a40] bg-[#222329] hover:bg-[#2b2c32]',
    formButtonPrimary: 'bg-[#ed5149] hover:bg-[#f5645b] text-white',
    formFieldInput: 'bg-[#141519] border-[#444148] text-[#f4f1ee]',
    footerAction: 'text-[#aaa6a5]',
    dividerLine: 'bg-[#3d3a40]',
    alert: 'bg-[#2b2225] border-[#653f41]',
    otpCodeFieldInput: 'bg-[#141519] border-[#444148] text-[#f4f1ee]',
    formFieldRow: 'text-[#f4f1ee]',
    main: 'text-[#f4f1ee]',
  },
};
function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}
function ClerkRoutes() {
  const [, setLocation] = useLocation();
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={clerkAppearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} localization={{
    signIn: { start: { title: 'Welcome back', subtitle: 'Pick up right where you left off.' } },
    signUp: { start: { title: 'Find your frequency', subtitle: 'A new corner of the internet is yours.' } },
  }} routerPush={to => setLocation(stripBase(to))} routerReplace={to => setLocation(stripBase(to), { replace: true })}>
    <AppState><Switch>
      <Route path="/" component={HomeRedirect} />
      <Route path="/user-portal" component={PortalRedirect} />
      <Route path="/search" component={SearchPage} />
      <Route path="/watch/:videoId" component={WatchPage} />
      <Route path="/shorts" component={ShortsPage} />
      <Route path="/upload" component={UploadPage} />
      <Route path="/profile" component={ProfilePage} />
      <Route path="/sign-in/*?" component={() => <AuthPage mode="sign-in" />} />
      <Route path="/sign-up/*?" component={() => <AuthPage mode="sign-up" />} />
      <Route component={() => <AppShell><div className="empty-state"><span className="empty-icon"><Compass /></span><h2>This corner is still being found.</h2><p>The page you asked for is not here. Head back to the feed and take another route.</p><Link className="primary-button" href="/user-portal">Go home</Link></div></AppShell>} />
    </Switch></AppState>
  </ClerkProvider>;
}
function App() {
  if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY');
  return <WouterRouter base={basePath}><ClerkRoutes /></WouterRouter>;
}
export default App;